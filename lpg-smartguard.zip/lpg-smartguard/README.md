# 🔥 LPG SmartGuard

### IoT-Based Smart LPG Leakage Detection and Auto-Refill System

[![Platform](https://img.shields.io/badge/Platform-ESP32-blue)](https://www.espressif.com/en/products/socs/esp32)
[![Sensor](https://img.shields.io/badge/Sensor-MQ--2-orange)](https://www.hwsensor.com)
[![Backend](https://img.shields.io/badge/Backend-Node.js-green)](https://nodejs.org)
[![License](https://img.shields.io/badge/License-MIT-yellow)](LICENSE)

> A low-cost, real-time LPG safety system built on ESP32 that detects gas leaks, auto-closes a solenoid valve, and triggers automatic cylinder refill bookings — all monitored via a live web dashboard.

---

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [System Architecture](#system-architecture)
- [Hardware Requirements](#hardware-requirements)
- [Wiring / GPIO Assignment](#wiring--gpio-assignment)
- [Software Setup](#software-setup)
  - [Firmware (ESP32)](#firmware-esp32)
  - [Node.js Server](#nodejs-server)
- [Configuration](#configuration)
- [Dashboard](#dashboard)
- [API Reference](#api-reference)
- [Performance Metrics](#performance-metrics)
- [Project Report](#project-report)
- [Authors](#authors)
- [License](#license)

---

## Overview

LPG SmartGuard addresses two critical problems with domestic LPG usage in India:

1. **Safety** — Undetected gas leaks cause fires and explosions. This system detects dangerous concentrations and autonomously shuts off gas flow within **< 2 seconds**.
2. **Convenience** — Manual cylinder monitoring leads to mid-cooking shortages. The system tracks gas level via a firmware-based **Virtual Weight Model** and auto-books a refill when the level drops below 20%.

The system is built around the **ESP32 microcontroller**, an **MQ-2 gas sensor**, a **solenoid valve**, and a **Node.js + web dashboard** backend — with a total hardware BOM cost of approximately **₹1,650**.

---

## Features

| Feature | Details |
|---|---|
| ⚡ Real-time gas detection | MQ-2 sensor, 2-second polling interval |
| 🔒 Auto valve shutoff | Solenoid valve closes in avg. **1.4 seconds** on leak detection |
| 📊 Virtual Weight Model | Firmware-based level estimation — no load cell needed |
| 🔔 Audible alert | Active buzzer with continuous tone on danger, 3 beeps on warning |
| 📲 Push notifications | Webhook-based browser notifications via Node.js |
| 📦 Auto-refill booking | Triggers at ≤ 20% cylinder level automatically |
| 🌐 Web dashboard | Live PPM gauge, level indicator, event log, manual controls |
| 💾 State persistence | NVS flash write every 60 s — survives power cycles |
| 🔌 Fail-safe design | Normally-closed solenoid valve: gas off on power loss |

---

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    PERCEPTION LAYER                              │
│  MQ-2 Gas Sensor ──► ADC (GPIO34, 12-bit) ──► PPM Conversion    │
└──────────────────────────────┬──────────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────────┐
│                   PROCESSING LAYER (ESP32)                       │
│  Safety Logic │ Virtual Level Model │ HTTP Server (port 80)      │
│  GPIO Driver  │ NVS Flash Persist   │ HTTP Client (telemetry)    │
└──────┬────────────────────────────────────────┬─────────────────┘
       │ GPIO                                    │ Wi-Fi HTTP
       ▼                                         ▼
  Solenoid Valve                    ┌────────────────────────┐
  Active Buzzer                     │   Node.js Server :3000  │
                                    │   Web Dashboard (HTML)  │
                                    │   Webhook Notifications │
                                    │   Refill Booking API    │
                                    └────────────────────────┘
```

---

## Hardware Requirements

| # | Component | Specification | Approx. Cost |
|---|---|---|---|
| 1 | ESP32 DevKitC V4 | Dual-core 240 MHz, Wi-Fi+BT | ₹400 |
| 2 | MQ-2 Gas Sensor Module | SnO₂, 5V, Analog+Digital output | ₹120 |
| 3 | Active Buzzer | 5V, 85 dB, 12 mm through-hole | ₹30 |
| 4 | 5V Relay Module | Single channel, optocoupler isolated | ₹80 |
| 5 | Solenoid Valve | 12V NC, G1/4", LPG-rated brass body | ₹650 |
| 6 | 12V DC Adapter | 1A, 5.5/2.1 mm DC jack | ₹150 |
| 7 | 5V USB supply / AMS1117 regulator | For ESP32 | ₹50 |
| 8 | Breadboard + jumper wires | 830-tie, M-M and M-F | ₹170 |
| | **Total** | | **~₹1,650** |

---

## Wiring / GPIO Assignment

| GPIO | Connected To | Direction | Function |
|---|---|---|---|
| GPIO34 (ADC1_CH6) | MQ-2 AOUT | Input (Analog) | Gas concentration (PPM) reading |
| GPIO35 | MQ-2 DOUT | Input (Digital) | Threshold-crossed digital flag |
| GPIO26 | Buzzer (+) | Output (Digital) | Audible alert — HIGH = ON |
| GPIO27 | Relay IN | Output (Digital) | Solenoid valve — HIGH = OPEN |

> ⚠️ **Important:** Use a 10 kΩ / 10 kΩ voltage divider between the MQ-2 AOUT and GPIO34 to scale the 0–5V output to the ESP32's 3.3V ADC range. Place a 1N4007 flyback diode across the solenoid coil terminals.

---

## Software Setup

### Firmware (ESP32)

**Prerequisites:**
- [Arduino IDE 2.x](https://www.arduino.cc/en/software) or [PlatformIO](https://platformio.org/)
- ESP32 board package v3.0.1+ (Espressif) — install via Board Manager
- Library: `ArduinoJson` v6.21.3 — install via Library Manager

**Steps:**

```bash
# 1. Clone the repository
git clone https://github.com/<your-username>/lpg-smartguard.git
cd lpg-smartguard/firmware

# 2. Open lpg_smartguard.ino in Arduino IDE

# 3. Edit config section at the top of the file:
#    - WIFI_SSID / WIFI_PASSWORD
#    - SERVER_HOST (IP of your Node.js machine)
#    - DANGER_THRESHOLD / WARNING_THRESHOLD (ADC values)
#    - REFILL_LEVEL (default: 20%)

# 4. Select board: ESP32 Dev Module
#    Flash frequency: 80 MHz, Partition scheme: Default 4MB

# 5. Upload
```

**MQ-2 Warm-up:** Allow **40 seconds** after power-on before readings stabilise. Full calibration takes 48 hours in clean air.

---

### Node.js Server

**Prerequisites:** Node.js v18+

```bash
cd lpg-smartguard/server

# Install dependencies
npm install

# Start the server
node server.js

# Server runs on http://localhost:3000
# Dashboard: http://localhost:3000
```

Update `SERVER_HOST` in the firmware to the LAN IP of the machine running the Node.js server (e.g., `192.168.1.100`).

---

## Configuration

All configurable parameters are at the top of `firmware/lpg_smartguard.ino`:

```cpp
// Wi-Fi credentials
const char* WIFI_SSID     = "YOUR_SSID";
const char* WIFI_PASSWORD = "YOUR_PASSWORD";

// Node.js server
const char* SERVER_HOST = "192.168.1.100";
const int   SERVER_PORT = 3000;

// Detection thresholds (ADC raw values, 0–4095)
const int DANGER_THRESHOLD  = 1500;  // ~600 PPM — closes valve + buzzer
const int WARNING_THRESHOLD = 900;   // ~300 PPM — 3 beeps

// Cylinder settings
const float REFILL_LEVEL        = 20.0;   // % — triggers auto-refill
const long  FULL_DURATION_DAYS  = 30;     // days for a full cylinder
```

---

## Dashboard

The web dashboard (`server/public/index.html`) is a single-page app with no external framework dependencies.

**Panels:**
- **Virtual Gas Level** — Circular gauge + manual override slider (100% / 75% / 50% / 25% presets)
- **MQ-2 Sensor** — Live PPM readout + historical chart + CLEAN / WARNING / DANGER indicator
- **System Status** — Valve state, leak flag, refill status, uptime
- **Alert Log** — Timestamped event history (leak detected, cleared, refill booked, reset)
- **Controls** — Simulate Leak, Clear Leak, Book Refill, Reset Cylinder, Auto-drain toggle

The dashboard polls `GET /api/state` every **2 seconds** for live data.

---

## API Reference

### ESP32 HTTP Server (port 80)

| Endpoint | Method | Description |
|---|---|---|
| `/status` | GET | Returns current system state as JSON |
| `/setlevel` | POST | Override cylinder level (`{"level": 85}`) |
| `/reset` | POST | Clear all alert flags, reopen valve |

### Node.js Server (port 3000)

| Endpoint | Method | Description |
|---|---|---|
| `/` | GET | Serves web dashboard |
| `/api/status` | POST | Receives ESP32 telemetry |
| `/api/alert` | POST | Receives alert events, appends to log |
| `/api/book-refill` | POST | Logs refill booking with timestamp |
| `/api/notify` | POST | Webhook — browser push notification dispatch |
| `/api/state` | GET | Returns current system state as JSON |

---

## Performance Metrics

| Metric | Target | Measured |
|---|---|---|
| Leak detection → valve close | < 2 s | **1.4 s avg** |
| Level estimation error | < 5% | **0.37% avg** |
| Wi-Fi connect time on boot | < 10 s | **3.2 s** |
| Dashboard polling latency | < 3 s | **18 ms avg (LAN)** |
| Auto-refill trigger accuracy | At 20% | **20.0%** |
| NVS state persistence | Survives reboot | ✅ Confirmed |
| System power (idle) | < 0.5 W | **~0.28 W** |

---

## Project Report

The full project report is available at [`docs/LPG_SmartGuard_Report.pdf`](docs/LPG_SmartGuard_Report.pdf).

---

## Authors

| Name | Roll No. |
|---|---|
| Ch. Navya Sri Lakshmi | 160123735006 |
| Kangula Jai Lakshmi | 160123735011 |
| Md. Nayeemoddin | 160123735045 |

**Supervisor:** Dr. D. Siva Priyanka, Assistant Professor, Dept. of ECE  
**Institution:** Chaitanya Bharathi Institute of Technology, Hyderabad — 500075  
**Academic Year:** 2025–2026

---

## License

This project is licensed under the [MIT License](LICENSE).

---

*Built for Hackathon 2026 — Embedded Systems with Real-World Social Impact*
