/**
 * LPG SmartGuard — ESP32 Firmware
 * IoT-Based Smart LPG Leakage Detection and Auto-Refill System
 *
 * Hardware:  ESP32 DevKitC V4
 * Framework: Arduino-ESP32 v3.0.1
 * Libraries: ArduinoJson v6.21.3, ESP32 WebServer (built-in)
 *
 * Authors:
 *   Ch. Navya Sri Lakshmi  (160123735006)
 *   Kangula Jai Lakshmi    (160123735011)
 *   Md. Nayeemoddin        (160123735045)
 *
 * Supervisor: Dr. D. Siva Priyanka
 * Dept. of ECE, CBIT Hyderabad — 2025-2026
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <WebServer.h>
#include <ArduinoJson.h>
#include <Preferences.h>  // NVS flash persistence

// ──────────────────────────────────────────────
//  USER CONFIGURATION — edit before flashing
// ──────────────────────────────────────────────
const char* WIFI_SSID     = "YOUR_SSID";
const char* WIFI_PASSWORD = "YOUR_PASSWORD";
const char* SERVER_HOST   = "192.168.1.100";  // IP of Node.js machine
const int   SERVER_PORT   = 3000;

// ADC thresholds (raw 12-bit, 0–4095)
const int DANGER_THRESHOLD  = 1500;  // ~600 PPM → valve close + buzzer
const int WARNING_THRESHOLD = 900;   // ~300 PPM → 3 warning beeps

// Cylinder settings
const float REFILL_LEVEL       = 20.0f;   // % — triggers auto-refill booking
const long  FULL_DURATION_DAYS = 30;      // days a full 14.2 kg cylinder lasts
// ──────────────────────────────────────────────

// GPIO pin assignments
#define PIN_MQ2_AOUT   34   // ADC1_CH6 — analog gas concentration
#define PIN_MQ2_DOUT   35   // Digital threshold flag from MQ-2 module
#define PIN_BUZZER     26   // Active buzzer (HIGH = ON)
#define PIN_RELAY      27   // Relay IN — controls solenoid valve (HIGH = OPEN)

// Timing constants
const unsigned long STATUS_INTERVAL_MS  = 5000;   // Push telemetry every 5 s
const unsigned long NVS_SAVE_INTERVAL_MS = 60000;  // Save level to flash every 60 s
const unsigned long SENSOR_READ_MS      = 2000;   // Read sensor every 2 s
const long FULL_DURATION_MS = (long)FULL_DURATION_DAYS * 24UL * 3600UL * 1000UL;

// MQ-2 sensitivity curve constants (log-log fit for LPG)
// PPM = 1000 * ( (Rs/Ro) / 0.4 ) ^ -2.3
const float MQ2_RO_CLEAN_AIR = 9.83f;  // Calibrated Ro in clean air (kΩ)
const float RL_VALUE         = 10.0f;  // Load resistance on module (kΩ)

// ──────────────────────────────────────────────
//  Global state
// ──────────────────────────────────────────────
struct SystemState {
  float   levelPct    = 100.0f;
  int     rawADC      = 0;
  float   ppm         = 0.0f;
  bool    leakActive  = false;
  bool    valveOpen   = true;
  bool    buzzerOn    = false;
  bool    refillBooked = false;
  unsigned long uptimeMs = 0;
};

SystemState state;
WebServer    httpServer(80);
Preferences  prefs;

unsigned long lastStatusSend  = 0;
unsigned long lastNVSSave     = 0;
unsigned long lastSensorRead  = 0;
unsigned long lastLevelUpdate = 0;  // millis() at last level decrement

// ──────────────────────────────────────────────
//  MQ-2 PPM conversion
// ──────────────────────────────────────────────
float adcToPPM(int raw) {
  if (raw <= 0) return 0.0f;
  float voltage = (raw / 4095.0f) * 3.3f;
  float rs = ((3.3f - voltage) / voltage) * RL_VALUE;
  float ratio = rs / MQ2_RO_CLEAN_AIR;
  float ppm = 1000.0f * pow((ratio / 0.4f), -2.3f);
  return max(0.0f, ppm);
}

// Median filter over 5 ADC samples
int filteredADCRead(int pin) {
  int samples[5];
  for (int i = 0; i < 5; i++) {
    samples[i] = analogRead(pin);
    delay(5);
  }
  // Insertion sort
  for (int i = 1; i < 5; i++) {
    int key = samples[i], j = i - 1;
    while (j >= 0 && samples[j] > key) { samples[j+1] = samples[j]; j--; }
    samples[j+1] = key;
  }
  return samples[2];  // median
}

// ──────────────────────────────────────────────
//  Virtual Weight Model — Equation (2)
//  Level(%) = Level_initial(%) - [elapsed_ms / full_duration_ms * 100]
// ──────────────────────────────────────────────
void updateVirtualLevel() {
  unsigned long now = millis();
  float elapsedMs = (float)(now - lastLevelUpdate);
  lastLevelUpdate = now;

  // During active leak, model 5× accelerated depletion
  float multiplier = state.leakActive ? 5.0f : 1.0f;

  float decrement = (elapsedMs / (float)FULL_DURATION_MS) * 100.0f * multiplier;
  state.levelPct -= decrement;
  state.levelPct = constrain(state.levelPct, 0.0f, 100.0f);

  // Auto-refill booking
  if (state.levelPct <= REFILL_LEVEL && !state.refillBooked) {
    state.refillBooked = true;
    bookRefill();
  }

  // Close valve if cylinder empty
  if (state.levelPct <= 0.0f) {
    setValve(false);
  }
}

// ──────────────────────────────────────────────
//  Safety evaluation (called every SENSOR_READ_MS)
// ──────────────────────────────────────────────
void evaluateSafety() {
  state.rawADC = filteredADCRead(PIN_MQ2_AOUT);
  state.ppm    = adcToPPM(state.rawADC);

  if (state.rawADC >= DANGER_THRESHOLD) {
    // DANGER — close valve, continuous buzz, send webhook
    if (!state.leakActive) {
      state.leakActive = true;
      setValve(false);
      setBuzzer(true);
      sendAlert("LEAK_DETECTED", state.rawADC, state.ppm);
    }
  } else if (state.rawADC >= WARNING_THRESHOLD) {
    // WARNING — 3 short beeps
    if (!state.leakActive) {
      warningBeeps(3);
    }
  } else {
    // SAFE — ensure valve open and buzzer off (unless overridden)
    if (state.leakActive) {
      // Leak auto-clears only after PPM drops well below warning
      // (operator should confirm via dashboard Clear Leak button)
    }
  }
}

// ──────────────────────────────────────────────
//  Actuator helpers
// ──────────────────────────────────────────────
void setValve(bool open) {
  state.valveOpen = open;
  digitalWrite(PIN_RELAY, open ? HIGH : LOW);
}

void setBuzzer(bool on) {
  state.buzzerOn = on;
  digitalWrite(PIN_BUZZER, on ? HIGH : LOW);
}

void warningBeeps(int n) {
  for (int i = 0; i < n; i++) {
    digitalWrite(PIN_BUZZER, HIGH); delay(200);
    digitalWrite(PIN_BUZZER, LOW);  delay(200);
  }
}

// ──────────────────────────────────────────────
//  HTTP Client — push telemetry to Node.js server
// ──────────────────────────────────────────────
String serverURL(const char* path) {
  return String("http://") + SERVER_HOST + ":" + SERVER_PORT + path;
}

void publishStatus() {
  if (WiFi.status() != WL_CONNECTED) return;

  StaticJsonDocument<256> doc;
  doc["level"]       = state.levelPct;
  doc["raw_adc"]     = state.rawADC;
  doc["ppm"]         = state.ppm;
  doc["leak"]        = state.leakActive;
  doc["valve_open"]  = state.valveOpen;
  doc["buzzer"]      = state.buzzerOn;
  doc["refill_booked"] = state.refillBooked;
  doc["uptime_ms"]   = millis();

  String body;
  serializeJson(doc, body);

  HTTPClient http;
  http.begin(serverURL("/api/status"));
  http.addHeader("Content-Type", "application/json");
  http.POST(body);
  http.end();
}

void sendAlert(const char* type, int raw, float ppm) {
  if (WiFi.status() != WL_CONNECTED) return;

  StaticJsonDocument<128> doc;
  doc["type"]    = type;
  doc["raw_adc"] = raw;
  doc["ppm"]     = ppm;
  doc["level"]   = state.levelPct;

  String body;
  serializeJson(doc, body);

  HTTPClient http;
  http.begin(serverURL("/api/alert"));
  http.addHeader("Content-Type", "application/json");
  http.POST(body);
  http.end();
}

void bookRefill() {
  if (WiFi.status() != WL_CONNECTED) return;

  StaticJsonDocument<64> doc;
  doc["level"]     = state.levelPct;
  doc["auto"]      = true;

  String body;
  serializeJson(doc, body);

  HTTPClient http;
  http.begin(serverURL("/api/book-refill"));
  http.addHeader("Content-Type", "application/json");
  http.POST(body);
  http.end();

  Serial.println("[REFILL] Auto-refill booking sent.");
}

// ──────────────────────────────────────────────
//  NVS persistence
// ──────────────────────────────────────────────
void saveStateToNVS() {
  prefs.begin("smartguard", false);
  prefs.putFloat("level", state.levelPct);
  prefs.putBool("refill_booked", state.refillBooked);
  prefs.end();
  Serial.printf("[NVS] Saved: level=%.1f%%\n", state.levelPct);
}

void loadStateFromNVS() {
  prefs.begin("smartguard", true);
  state.levelPct     = prefs.getFloat("level", 100.0f);
  state.refillBooked = prefs.getBool("refill_booked", false);
  prefs.end();
  Serial.printf("[NVS] Loaded: level=%.1f%%\n", state.levelPct);
}

// ──────────────────────────────────────────────
//  ESP32 HTTP Server endpoints (port 80)
// ──────────────────────────────────────────────
void handleGetStatus() {
  StaticJsonDocument<256> doc;
  doc["level"]        = state.levelPct;
  doc["raw_adc"]      = state.rawADC;
  doc["ppm"]          = state.ppm;
  doc["leak"]         = state.leakActive;
  doc["valve_open"]   = state.valveOpen;
  doc["buzzer"]       = state.buzzerOn;
  doc["refill_booked"]= state.refillBooked;
  doc["uptime_ms"]    = millis();
  doc["ip"]           = WiFi.localIP().toString();

  String resp;
  serializeJson(doc, resp);
  httpServer.send(200, "application/json", resp);
}

void handleSetLevel() {
  if (!httpServer.hasArg("plain")) {
    httpServer.send(400, "text/plain", "No body");
    return;
  }
  StaticJsonDocument<64> doc;
  deserializeJson(doc, httpServer.arg("plain"));
  float newLevel = doc["level"] | state.levelPct;
  state.levelPct = constrain(newLevel, 0.0f, 100.0f);
  // Reset refill flag if level was bumped back up
  if (state.levelPct > REFILL_LEVEL) state.refillBooked = false;
  lastLevelUpdate = millis();
  saveStateToNVS();
  httpServer.send(200, "application/json", "{\"ok\":true}");
  Serial.printf("[CMD] Level set to %.1f%%\n", state.levelPct);
}

void handleReset() {
  state.leakActive = false;
  setBuzzer(false);
  setValve(true);
  httpServer.send(200, "application/json", "{\"ok\":true}");
  sendAlert("LEAK_CLEARED", state.rawADC, state.ppm);
  Serial.println("[CMD] System reset from dashboard.");
}

// ──────────────────────────────────────────────
//  setup() and loop()
// ──────────────────────────────────────────────
void setup() {
  Serial.begin(115200);

  // GPIO init
  pinMode(PIN_MQ2_DOUT, INPUT);
  pinMode(PIN_BUZZER,   OUTPUT);
  pinMode(PIN_RELAY,    OUTPUT);
  digitalWrite(PIN_BUZZER, LOW);
  digitalWrite(PIN_RELAY,  LOW);  // Valve closed until Wi-Fi ready

  // ADC config
  analogReadResolution(12);
  analogSetAttenuation(ADC_11db);  // 0–3.3V input range

  // Load persisted state
  loadStateFromNVS();
  lastLevelUpdate = millis();

  // Connect Wi-Fi
  Serial.printf("[WIFI] Connecting to %s", WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  unsigned long wifiStart = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - wifiStart < 15000) {
    delay(500); Serial.print(".");
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("\n[WIFI] Connected. IP: %s\n", WiFi.localIP().toString().c_str());
  } else {
    Serial.println("\n[WIFI] Failed — operating in local-only mode.");
  }

  // Open valve (normal operation)
  setValve(true);

  // Start HTTP server
  httpServer.on("/status",   HTTP_GET,  handleGetStatus);
  httpServer.on("/setlevel", HTTP_POST, handleSetLevel);
  httpServer.on("/reset",    HTTP_POST, handleReset);
  httpServer.begin();
  Serial.println("[HTTP] ESP32 server started on port 80.");

  // MQ-2 warm-up
  Serial.println("[MQ2] Warming up sensor (40 s)...");
  delay(40000);
  Serial.println("[MQ2] Ready.");
}

void loop() {
  httpServer.handleClient();
  state.uptimeMs = millis();

  // Sensor read + safety evaluation
  if (millis() - lastSensorRead >= SENSOR_READ_MS) {
    lastSensorRead = millis();
    evaluateSafety();
    updateVirtualLevel();
    Serial.printf("[SENSOR] ADC=%d  PPM=%.1f  Level=%.1f%%  Valve=%s\n",
                  state.rawADC, state.ppm, state.levelPct,
                  state.valveOpen ? "OPEN" : "CLOSED");
  }

  // Push telemetry to server
  if (millis() - lastStatusSend >= STATUS_INTERVAL_MS) {
    lastStatusSend = millis();
    publishStatus();
  }

  // NVS save
  if (millis() - lastNVSSave >= NVS_SAVE_INTERVAL_MS) {
    lastNVSSave = millis();
    saveStateToNVS();
  }
}
