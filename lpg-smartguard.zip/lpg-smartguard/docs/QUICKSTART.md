# LPG SmartGuard — Quick Start

## 1. Flash the ESP32

```bash
# Prerequisites: Arduino IDE 2.x + ESP32 board package v3.0.1+
# Library needed: ArduinoJson v6.21.3

# Open firmware/lpg_smartguard.ino
# Edit WIFI_SSID, WIFI_PASSWORD, SERVER_HOST at top of file
# Select: Board → ESP32 Dev Module, Port → your COM/tty port
# Click Upload
```

## 2. Start the Node.js Server

```bash
cd server
npm install
node server.js
# → Dashboard: http://localhost:3000
```

## 3. Find your server's LAN IP

```bash
# Windows
ipconfig

# macOS / Linux
ifconfig | grep inet
```

Set `SERVER_HOST` in the firmware to this IP (e.g., `192.168.1.105`), then re-flash.

## 4. Open the Dashboard

Navigate to `http://localhost:3000` in any browser on the same Wi-Fi network.

## 5. Hardware connections

See `hardware/WIRING.md` for the full circuit diagram and step-by-step guide.

---

## Thresholds (configurable in firmware)

| Constant | Default | Meaning |
|---|---|---|
| `DANGER_THRESHOLD` | 1500 ADC (~600 PPM) | Valve closes + buzzer |
| `WARNING_THRESHOLD` | 900 ADC (~300 PPM) | 3 warning beeps |
| `REFILL_LEVEL` | 20% | Auto-refill booking triggers |
| `FULL_DURATION_DAYS` | 30 | Days a full cylinder lasts |

## Troubleshooting

| Issue | Fix |
|---|---|
| Sensor reads 0 | Check 5V supply to MQ-2; wait 40 s warm-up |
| Wi-Fi won't connect | Verify SSID/password; ESP32 only supports 2.4 GHz |
| ADC2 conflict | Do not use GPIO0–GPIO3 for ADC while Wi-Fi is active |
| Valve won't open | Check 12V adapter; verify relay wiring (NO terminal) |
| Dashboard not updating | Confirm SERVER_HOST matches your machine's LAN IP |
