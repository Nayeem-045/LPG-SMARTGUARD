# Hardware Wiring Guide — LPG SmartGuard

## Circuit Overview

```
                     +5V ─────────────────────────────────────────┐
                                                                   │
                 ┌─────────────┐                         ┌────────┴───────┐
                 │   ESP32     │                         │   MQ-2 Module  │
                 │  DevKitC V4 │                         │                │
                 │             │    10kΩ/10kΩ divider    │  VCC  ──── +5V │
                 │  GPIO34 ◄───┼──────[10kΩ]──[10kΩ]────┤  AOUT          │
                 │  GPIO35 ◄───┼────────────────────────►│  DOUT          │
                 │             │                         │  GND  ──── GND │
                 │             │                         └────────────────┘
                 │             │
                 │  GPIO26 ────┼──────────────────────────────► Buzzer (+)
                 │             │                                Buzzer (─) → GND
                 │             │
                 │  GPIO27 ────┼────────────────────► Relay IN
                 │             │
                 │  3.3V  ─────┼────────────────────► Relay VCC
                 │  GND   ─────┼────────────────────► Relay GND
                 └─────────────┘
                                                  Relay COM ──► 12V (+)
                                                  Relay NO  ──► Solenoid Valve (+)
                                                  Solenoid Valve (─) ──► 12V GND
                                                  1N4007 flyback diode across valve terminals
```

## Step-by-Step Wiring

### 1. MQ-2 Gas Sensor to ESP32

| MQ-2 Pin | Wire To | Notes |
|---|---|---|
| VCC | +5V rail | Requires 5V — **not** 3.3V |
| GND | GND | Common ground |
| AOUT | Voltage divider mid-point → GPIO34 | See divider below |
| DOUT | GPIO35 | Direct 3.3V-compatible digital output |

**Voltage Divider for AOUT:**
```
MQ-2 AOUT ──[10kΩ]──┬──[10kΩ]── GND
                     │
                   GPIO34 (ESP32)
```
This scales 0–5V down to 0–2.5V, safely within the ESP32's 3.3V ADC range.

### 2. Active Buzzer

| Buzzer Pin | Wire To |
|---|---|
| + (longer leg) | GPIO26 |
| − (shorter leg) | GND |

### 3. Relay Module

| Relay Pin | Wire To |
|---|---|
| VCC | 3.3V (most optocoupler modules work at 3.3V) |
| GND | GND |
| IN  | GPIO27 |
| COM | 12V DC (+) from adapter |
| NO  | Solenoid valve (+) |

### 4. Solenoid Valve (12V NC)

| Solenoid Wire | Wire To |
|---|---|
| + (red) | Relay NO terminal |
| − (black) | 12V GND |

**CRITICAL:** Place a **1N4007 flyback diode** across the solenoid terminals:
- Cathode (stripe) → Solenoid (+)
- Anode → Solenoid (−)

This protects the relay and ESP32 from inductive voltage spikes when the coil de-energises.

### 5. Power Supply

- **ESP32**: 5V USB via onboard micro-USB, or AMS1117-5.0 regulator from the 12V adapter
- **MQ-2**: Tap 5V from the USB supply or regulator
- **Solenoid Valve**: 12V DC adapter (1A minimum)
- All GNDs must be connected to a common ground

## Sensor Placement

> ⚠️ LPG is **heavier than air** (specific gravity 1.5–2.0). Place the MQ-2 sensor **20–30 cm above floor level** for maximum sensitivity.

## Safety Notes

1. Test in a **well-ventilated outdoor area** when exposing to LPG
2. Never test near open flames
3. The solenoid valve must be **LPG-rated** (brass body, Teflon seals)
4. The normally-closed valve configuration means gas is OFF when power is lost (fail-safe)
5. Allow 40 seconds warm-up after power-on before trusting sensor readings
