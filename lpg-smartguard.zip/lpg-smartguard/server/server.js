/**
 * LPG SmartGuard — Node.js Express Server
 * Acts as IoT gateway between ESP32 and the web dashboard.
 *
 * Endpoints:
 *   GET  /              → Serves dashboard HTML
 *   POST /api/status    → Receives ESP32 telemetry
 *   POST /api/alert     → Receives alert events
 *   POST /api/book-refill → Logs refill bookings
 *   POST /api/notify    → Browser push notification dispatch
 *   GET  /api/state     → Returns current system state (polled by dashboard)
 */

const express = require('express');
const path    = require('path');
const crypto  = require('crypto');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ──────────────────────────────────────────────
//  In-memory system state
// ──────────────────────────────────────────────
let systemState = {
  level:         100.0,
  raw_adc:       0,
  ppm:           0.0,
  leak:          false,
  valve_open:    true,
  buzzer:        false,
  refill_booked: false,
  uptime_ms:     0,
  esp32_ip:      null,
  last_seen:     null,
};

let alertLog     = [];  // { id, type, raw_adc, ppm, level, timestamp }
let refillLog    = [];  // { booking_id, level, auto, timestamp }

// ──────────────────────────────────────────────
//  Helper
// ──────────────────────────────────────────────
function timestamp() {
  return new Date().toISOString();
}

function bookingId() {
  return 'VF-' + String(refillLog.length + 1).padStart(4, '0');
}

// ──────────────────────────────────────────────
//  Routes
// ──────────────────────────────────────────────

// Receive telemetry from ESP32
app.post('/api/status', (req, res) => {
  const d = req.body;
  systemState = {
    ...systemState,
    level:         d.level         ?? systemState.level,
    raw_adc:       d.raw_adc       ?? systemState.raw_adc,
    ppm:           d.ppm           ?? systemState.ppm,
    leak:          d.leak          ?? systemState.leak,
    valve_open:    d.valve_open    ?? systemState.valve_open,
    buzzer:        d.buzzer        ?? systemState.buzzer,
    refill_booked: d.refill_booked ?? systemState.refill_booked,
    uptime_ms:     d.uptime_ms     ?? systemState.uptime_ms,
    esp32_ip:      d.ip            ?? systemState.esp32_ip,
    last_seen:     timestamp(),
  };
  res.json({ ok: true });
});

// Receive alert events from ESP32
app.post('/api/alert', (req, res) => {
  const { type, raw_adc, ppm, level } = req.body;
  const entry = {
    id:        crypto.randomUUID().slice(0, 8),
    type,
    raw_adc,
    ppm,
    level,
    timestamp: timestamp(),
  };
  alertLog.unshift(entry);           // newest first
  if (alertLog.length > 100) alertLog.pop();

  // Update state flags based on alert type
  if (type === 'LEAK_DETECTED')  systemState.leak = true;
  if (type === 'LEAK_CLEARED')   systemState.leak = false;

  console.log(`[ALERT] ${type} | PPM=${ppm?.toFixed(1)} | Level=${level?.toFixed(1)}%`);
  res.json({ ok: true, id: entry.id });
});

// Auto/manual refill booking
app.post('/api/book-refill', (req, res) => {
  const { level, auto = false } = req.body;
  const booking = {
    booking_id: bookingId(),
    level,
    auto,
    timestamp: timestamp(),
  };
  refillLog.unshift(booking);
  if (refillLog.length > 50) refillLog.pop();

  systemState.refill_booked = true;

  // Add to alert log for dashboard display
  alertLog.unshift({
    id:        crypto.randomUUID().slice(0, 8),
    type:      'REFILL_BOOKED',
    level,
    booking_id: booking.booking_id,
    auto,
    timestamp: timestamp(),
  });

  console.log(`[REFILL] Booked ${booking.booking_id} | Level=${level?.toFixed(1)}% | Auto=${auto}`);
  res.json({ ok: true, booking_id: booking.booking_id });
});

// Webhook dispatch (browser push notifications)
app.post('/api/notify', (req, res) => {
  // In production: integrate with Web Push (web-push npm package)
  // or forward to a mobile push service (FCM/APNs)
  console.log('[NOTIFY]', req.body);
  res.json({ ok: true });
});

// Dashboard polls this every 2 s
app.get('/api/state', (req, res) => {
  res.json({
    system:   systemState,
    alerts:   alertLog.slice(0, 20),
    refills:  refillLog.slice(0, 10),
  });
});

// Dashboard simulation: manually trigger a leak event
app.post('/api/simulate-leak', (req, res) => {
  systemState.leak       = true;
  systemState.valve_open = false;
  systemState.buzzer     = true;
  systemState.ppm        = 2400;
  systemState.raw_adc    = 2100;
  alertLog.unshift({
    id: crypto.randomUUID().slice(0, 8),
    type: 'LEAK_DETECTED',
    raw_adc: 2100,
    ppm: 2400,
    level: systemState.level,
    timestamp: timestamp(),
  });
  console.log('[SIM] Leak simulated from dashboard.');
  res.json({ ok: true });
});

// Dashboard: clear leak
app.post('/api/clear-leak', (req, res) => {
  systemState.leak       = false;
  systemState.valve_open = true;
  systemState.buzzer     = false;
  alertLog.unshift({
    id: crypto.randomUUID().slice(0, 8),
    type: 'LEAK_CLEARED',
    timestamp: timestamp(),
  });
  res.json({ ok: true });
});

// Dashboard: override cylinder level
app.post('/api/set-level', (req, res) => {
  const { level } = req.body;
  if (typeof level !== 'number' || level < 0 || level > 100) {
    return res.status(400).json({ error: 'Invalid level' });
  }
  systemState.level = level;
  if (level > 20) systemState.refill_booked = false;
  if (level === 100) {
    alertLog.unshift({
      id: crypto.randomUUID().slice(0, 8),
      type: 'REFUELED',
      level,
      timestamp: timestamp(),
    });
  }
  res.json({ ok: true });
});

// ──────────────────────────────────────────────
//  Start
// ──────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🔥 LPG SmartGuard Server running on http://localhost:${PORT}`);
  console.log(`   Dashboard : http://localhost:${PORT}`);
  console.log(`   API state : http://localhost:${PORT}/api/state\n`);
});
